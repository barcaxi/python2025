from Party import Party

party = Party('FF', 'Fianna Fail', '#8c8c8c')
print(party.get_partyname())
party.set_partyname('Fianna Fail Nua')
print(party.get_partyname())

print(party.to_string())
print(party.to_dict())
